import os
import uvicorn
import httpx
import json
import secrets
import string
import base64
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

# Load key from local .env
load_dotenv()
MOONSHOT_API_KEY = os.getenv("MOONSHOT_API_KEY")

if not MOONSHOT_API_KEY:
    print("ERROR: MOONSHOT_API_KEY not found in .env file.")
    exit(1)

MOONSHOT_BASE_URL = "https://api.moonshot.ai/v1"
MOONSHOT_MODEL = "kimi-k2.5"

# ── Kill switch ───────────────────────────────────────────────────────────────
# Telegram KILL: strips tools from all Mimi requests — she cannot take any action.
# Telegram GO:   restores tools, resumes normal operation.
kill_switch_active = False

app = FastAPI()
print(f"Loading local embedding model (all-MiniLM-L6-v2) for Kimi Proxy...")
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
print("Local embedding model loaded!")

client = httpx.AsyncClient(
    base_url=MOONSHOT_BASE_URL,
    headers={"Authorization": f"Bearer {MOONSHOT_API_KEY}"},
    timeout=120.0
)

# ── Vision Loop-Back ───────────────────────────────────────────────────────────
# When Mimi calls any tool that produces an image file on disk, the proxy
# intercepts the file path from the tool arguments, reads and base64-encodes
# the image, then injects it back into the conversation as a user vision
# message immediately after the tool result. Kimi receives the image and
# Mimi can see it in her very next response — no human in the loop.
#
# To add a new tool, just add it to VISION_TRIGGER_TOOLS with the argument
# key(s) that contain the image file path.
VISION_TRIGGER_TOOLS = {
    "telegram_send_photo":                    ["photo", "file", "path", "image"],
    "mcp_playwright_browser_take_screenshot": ["path", "file", "save_path"],
    "mcp_mimi-vision_screenshot_and_see":     ["save_path", "path", "file"],
    "mcp_mimi-vision_read_image_and_see":     ["file_path", "path", "file"],
}

# Supported image extensions → MIME types
IMAGE_MIME_TYPES = {
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif":  "image/gif",
}


def extract_image_path_from_tool_call(tool_name: str, arguments: dict) -> str | None:
    """
    Given a tool name and its arguments, return the image file path if one exists
    on disk. Returns None if this tool isn't a vision trigger or no valid path found.
    """
    arg_keys = VISION_TRIGGER_TOOLS.get(tool_name)
    if not arg_keys:
        return None

    for key in arg_keys:
        value = arguments.get(key, "")
        if isinstance(value, str) and value.strip():
            path = Path(value.strip())
            if path.suffix.lower() in IMAGE_MIME_TYPES and path.exists():
                return str(path)

    return None


def encode_image_file(file_path: str) -> tuple[str, str] | None:
    """
    Read an image file from disk and return (base64_data, mime_type).
    Returns None if the file cannot be read.
    """
    try:
        path = Path(file_path)
        mime_type = IMAGE_MIME_TYPES.get(path.suffix.lower(), "image/png")
        with open(path, "rb") as f:
            image_b64 = base64.standard_b64encode(f.read()).decode("utf-8")
        print(f"[VISION LOOP] Encoded: {file_path} ({len(image_b64)} b64 chars, {mime_type})")
        return image_b64, mime_type
    except Exception as e:
        print(f"[VISION LOOP] Failed to encode {file_path}: {e}")
        return None


def build_vision_injection_message(file_path: str, tool_name: str) -> dict | None:
    """
    Build an OpenAI-format user message containing the image as an image_url block.
    This gets inserted into the message list so Kimi sees the image before responding.
    """
    result = encode_image_file(file_path)
    if not result:
        return None

    image_b64, mime_type = result
    data_url = f"data:{mime_type};base64,{image_b64}"

    return {
        "role": "user",
        "content": [
            {
                "type": "text",
                "text": (
                    f"[PROXY VISION LOOP] The tool '{tool_name}' produced this image. "
                    f"I am automatically feeding it back so you can see it visually. "
                    f"File: {file_path}"
                )
            },
            {
                "type": "image_url",
                "image_url": {"url": data_url}
            }
        ]
    }


def scan_messages_for_vision_triggers(openai_messages: list) -> list:
    """
    Walk the outgoing OpenAI message list. For every assistant message with
    tool calls that reference an image file, collect all pending vision
    injections and insert them AFTER all tool results for that assistant
    message are complete.

    This is critical: Kimi requires that an assistant message with tool_calls
    is followed immediately by ALL its tool result messages with nothing in
    between. Vision injection messages must come after the last tool result,
    never in the middle of a tool call/result sequence.

    Returns the updated message list with vision injections correctly placed.
    """
    # First pass: for each assistant message, collect image paths keyed by
    # the set of tool_call_ids in that message. We track which tool_call_id
    # is the LAST one so we know when to inject.
    #
    # Structure: { last_tool_call_id: [vision_msg, ...] }
    inject_after_last: dict[str, list] = {}

    for i, msg in enumerate(openai_messages):
        if msg.get("role") != "assistant" or not msg.get("tool_calls"):
            continue

        tool_calls = msg["tool_calls"]
        vision_msgs_for_this_assistant = []

        for tc in tool_calls:
            tool_name = tc.get("function", {}).get("name", "")
            args_raw = tc.get("function", {}).get("arguments", "{}")
            try:
                args = json.loads(args_raw) if isinstance(args_raw, str) else args_raw
            except Exception:
                args = {}

            image_path = extract_image_path_from_tool_call(tool_name, args)
            if image_path:
                print(f"[VISION LOOP] Trigger: {tool_name} -> {image_path}")
                vision_msg = build_vision_injection_message(image_path, tool_name)
                if vision_msg:
                    vision_msgs_for_this_assistant.append(vision_msg)

        if vision_msgs_for_this_assistant:
            # Find ALL tool_call_ids for this assistant message
            all_tool_ids = {tc.get("id", "") for tc in tool_calls}

            # Find the LAST tool result in the message list that belongs to
            # this assistant message — that's where we inject after
            last_tool_result_id = None
            for j in range(i + 1, len(openai_messages)):
                candidate = openai_messages[j]
                if candidate.get("role") == "tool" and candidate.get("tool_call_id") in all_tool_ids:
                    last_tool_result_id = candidate.get("tool_call_id")
                elif candidate.get("role") == "assistant":
                    # Hit the next assistant message — stop looking
                    break

            if last_tool_result_id:
                # Tag the last tool result with all vision messages to inject after it
                existing = inject_after_last.get(last_tool_result_id, [])
                existing.extend(vision_msgs_for_this_assistant)
                inject_after_last[last_tool_result_id] = existing
                print(f"[VISION LOOP] Will inject {len(vision_msgs_for_this_assistant)} vision message(s) after last tool result '{last_tool_result_id}'")

    # Second pass: rebuild list, injecting vision messages after the correct
    # tool result — only after ALL tool results for an assistant message are done
    result = []
    seen_tool_ids: set[str] = set()

    for msg in openai_messages:
        result.append(msg)

        if msg.get("role") == "tool":
            tool_call_id = msg.get("tool_call_id", "")
            seen_tool_ids.add(tool_call_id)

            if tool_call_id in inject_after_last:
                for vision_msg in inject_after_last[tool_call_id]:
                    result.append(vision_msg)
                print(f"[VISION LOOP] Injected {len(inject_after_last[tool_call_id])} vision message(s) after '{tool_call_id}'")

    return result


# ── ID Mapping for tool calls ──────────────────────────────────────────────────
class IDMapper:
    """Bidirectional ID mapping between Kimi and Anthropic formats."""

    def __init__(self):
        self.kimi_to_anthropic = {}
        self.anthropic_to_kimi = {}
        self.reasoning_cache = {}

    def register(self, kimi_id, anthropic_id):
        self.kimi_to_anthropic[kimi_id] = anthropic_id
        self.anthropic_to_kimi[anthropic_id] = kimi_id
        print(f"[ID MAP] {kimi_id} <-> {anthropic_id}")

    def to_anthropic(self, kimi_id):
        return self.kimi_to_anthropic.get(kimi_id)

    def to_kimi(self, anthropic_id):
        return self.anthropic_to_kimi.get(anthropic_id)

    def cache_reasoning(self, kimi_tool_id, reasoning_content):
        if reasoning_content:
            self.reasoning_cache[kimi_tool_id] = reasoning_content
            print(f"[REASONING CACHE] Stored for {kimi_tool_id}: {len(reasoning_content)} chars")

    def get_reasoning(self, kimi_tool_id):
        reasoning = self.reasoning_cache.get(kimi_tool_id)
        if reasoning:
            print(f"[REASONING CACHE] Hit for {kimi_tool_id}: {len(reasoning)} chars")
        else:
            print(f"[REASONING CACHE] Miss for {kimi_tool_id}")
            print(f"[REASONING CACHE] Available keys: {list(self.reasoning_cache.keys())}")
        return reasoning


# Global instance
id_mapper = IDMapper()


def generate_anthropic_id(prefix="msg"):
    """Generate random Anthropic-style IDs."""
    chars = string.ascii_letters + string.digits
    rand = ''.join(secrets.choice(chars) for _ in range(22))
    return f"{prefix}_01{rand}"


def convert_anthropic_image_block(part):
    """
    Convert an Anthropic image content block to OpenAI image_url format.

    Anthropic format:
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "..."}}
        {"type": "image", "source": {"type": "url", "url": "https://..."}}

    OpenAI format:
        {"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}}
        {"type": "image_url", "image_url": {"url": "https://..."}}
    """
    source = part.get("source", {})
    src_type = source.get("type")

    if src_type == "base64":
        media_type = source.get("media_type", "image/jpeg")
        data = source.get("data", "")
        url = f"data:{media_type};base64,{data}"
    elif src_type == "url":
        url = source.get("url", "")
    else:
        print(f"[WARN] Unknown image source type: {src_type}")
        return None

    return {"type": "image_url", "image_url": {"url": url}}


def convert_anthropic_messages(anthropic_msgs):
    """Convert Anthropic messages to OpenAI format with proper tool, image, and reasoning_content handling."""
    openai_msgs = []

    for msg in anthropic_msgs:
        role = msg.get("role")
        content = msg.get("content")

        if isinstance(content, list):
            text_parts = []
            tool_calls = []
            has_tool_result = False
            openai_content_blocks = []

            for part in content:
                ptype = part.get("type")

                if ptype == "text":
                    text_parts.append(part.get("text", ""))
                    openai_content_blocks.append({"type": "text", "text": part.get("text", "")})

                elif ptype == "image":
                    converted = convert_anthropic_image_block(part)
                    if converted:
                        openai_content_blocks.append(converted)
                        print(f"[IMAGE] Converted image block (source type: {part.get('source', {}).get('type')})")
                    else:
                        print(f"[WARN] Failed to convert image block: {part}")

                elif ptype == "tool_use":
                    anthropic_id = part.get("id")
                    kimi_id = id_mapper.to_kimi(anthropic_id)
                    if not kimi_id:
                        kimi_id = f"call_{generate_anthropic_id('')[:8]}"
                        id_mapper.register(kimi_id, anthropic_id)

                    tool_calls.append({
                        "id": kimi_id,
                        "type": "function",
                        "function": {
                            "name": part.get("name"),
                            "arguments": json.dumps(part.get("input", {}))
                        }
                    })

                elif ptype == "tool_result":
                    has_tool_result = True
                    anthropic_tool_id = part.get("tool_use_id")
                    kimi_tool_id = id_mapper.to_kimi(anthropic_tool_id)

                    if not kimi_tool_id:
                        kimi_tool_id = anthropic_tool_id
                        print(f"[WARN] No cached mapping for tool_result id={anthropic_tool_id}, using as-is")

                    result_content = part.get("content", "")
                    if isinstance(result_content, list):
                        tool_result_blocks = []
                        for block in result_content:
                            if isinstance(block, dict):
                                if block.get("type") == "text":
                                    tool_result_blocks.append({"type": "text", "text": block.get("text", "")})
                                elif block.get("type") == "image":
                                    converted = convert_anthropic_image_block(block)
                                    if converted:
                                        tool_result_blocks.append(converted)
                                        print(f"[IMAGE] Converted image inside tool_result")
                            elif isinstance(block, str):
                                tool_result_blocks.append({"type": "text", "text": block})

                        if len(tool_result_blocks) == 1 and tool_result_blocks[0]["type"] == "text":
                            result_payload = tool_result_blocks[0]["text"]
                        else:
                            result_payload = tool_result_blocks
                    else:
                        result_payload = str(result_content)

                    openai_msgs.append({
                        "role": "tool",
                        "tool_call_id": kimi_tool_id,
                        "content": result_payload
                    })

            # Build assistant message if needed
            if role == "assistant":
                if text_parts or tool_calls:
                    msg_obj = {"role": "assistant"}
                    if text_parts:
                        msg_obj["content"] = "".join(text_parts)
                    if tool_calls:
                        msg_obj["tool_calls"] = tool_calls
                        first_tool_id = tool_calls[0]["id"]
                        reasoning = id_mapper.get_reasoning(first_tool_id)
                        if reasoning:
                            msg_obj["reasoning_content"] = reasoning
                            print(f"[REASONING INJECT] For tool {first_tool_id}: {len(reasoning)} chars")
                        else:
                            msg_obj["reasoning_content"] = "Using tool to fulfill user request."
                            print(f"[REASONING FALLBACK] Generated for tool {first_tool_id}")
                    openai_msgs.append(msg_obj)

            elif role == "user" and not has_tool_result:
                if openai_content_blocks:
                    if len(openai_content_blocks) == 1 and openai_content_blocks[0]["type"] == "text":
                        openai_msgs.append({"role": "user", "content": openai_content_blocks[0]["text"]})
                    else:
                        openai_msgs.append({"role": "user", "content": openai_content_blocks})
                        print(f"[IMAGE] Sending multimodal user message with {len(openai_content_blocks)} blocks")

        else:
            if content:
                openai_msgs.append({"role": role, "content": content})

    return openai_msgs


def convert_anthropic_tools(anthropic_tools):
    """Convert Anthropic tool definitions to OpenAI format."""
    if not anthropic_tools:
        return None

    openai_tools = []
    for tool in anthropic_tools:
        openai_tools.append({
            "type": "function",
            "function": {
                "name": tool.get("name"),
                "description": tool.get("description", ""),
                "parameters": tool.get("input_schema", {})
            }
        })
    return openai_tools


async def stream_anthropic_response(openai_resp, model_name):
    """
    Convert OpenAI response to Anthropic SSE format.
    CRITICAL: Always send text block first, then tool_use blocks.
    """
    choice = openai_resp["choices"][0]
    message = choice["message"]
    usage = openai_resp.get("usage", {})

    reasoning_content = message.get("reasoning_content", "")
    msg_id = generate_anthropic_id("msg")

    msg_start = {
        "type": "message_start",
        "message": {
            "id": msg_id,
            "type": "message",
            "role": "assistant",
            "content": [],
            "model": model_name,
            "stop_reason": None,
            "stop_sequence": None,
            "usage": {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": 0
            }
        }
    }
    yield f"event: message_start\ndata: {json.dumps(msg_start)}\n\n"
    yield f"event: ping\ndata: {json.dumps({'type': 'ping'})}\n\n"

    current_index = 0
    text_content = message.get("content") or ""

    yield f"event: content_block_start\ndata: {json.dumps({'type': 'content_block_start', 'index': current_index, 'content_block': {'type': 'text', 'text': ''}})}\n\n"

    if text_content:
        chunk_size = 40
        for i in range(0, len(text_content), chunk_size):
            chunk = text_content[i:i+chunk_size]
            yield f"event: content_block_delta\ndata: {json.dumps({'type': 'content_block_delta', 'index': current_index, 'delta': {'type': 'text_delta', 'text': chunk}})}\n\n"

    yield f"event: content_block_stop\ndata: {json.dumps({'type': 'content_block_stop', 'index': current_index})}\n\n"
    current_index += 1

    tool_calls = message.get("tool_calls")
    if tool_calls:
        for tc in tool_calls:
            kimi_id = tc.get("id", "")
            anthropic_id = generate_anthropic_id("toolu")
            id_mapper.register(kimi_id, anthropic_id)

            if reasoning_content:
                id_mapper.cache_reasoning(kimi_id, reasoning_content)

            tool_name = tc.get("function", {}).get("name", "unknown")
            tool_args_raw = tc.get("function", {}).get("arguments", "{}")

            if isinstance(tool_args_raw, str):
                try:
                    tool_args = json.loads(tool_args_raw)
                except Exception:
                    tool_args = {}
            else:
                tool_args = tool_args_raw or {}

            args_json = json.dumps(tool_args)
            print(f"[SSE] Tool: {tool_name} | {kimi_id} -> {anthropic_id}")

            yield f"event: content_block_start\ndata: {json.dumps({'type': 'content_block_start', 'index': current_index, 'content_block': {'type': 'tool_use', 'id': anthropic_id, 'name': tool_name, 'input': {}}})}\n\n"

            chunk_size = 64
            for i in range(0, len(args_json), chunk_size):
                chunk = args_json[i:i+chunk_size]
                yield f"event: content_block_delta\ndata: {json.dumps({'type': 'content_block_delta', 'index': current_index, 'delta': {'type': 'input_json_delta', 'partial_json': chunk}})}\n\n"

            yield f"event: content_block_stop\ndata: {json.dumps({'type': 'content_block_stop', 'index': current_index})}\n\n"
            current_index += 1

    stop_reason = "tool_use" if tool_calls else "end_turn"
    msg_delta = {
        "type": "message_delta",
        "delta": {"stop_reason": stop_reason, "stop_sequence": None},
        "usage": {"output_tokens": usage.get("completion_tokens", 0)}
    }
    yield f"event: message_delta\ndata: {json.dumps(msg_delta)}\n\n"
    yield f"event: message_stop\ndata: {json.dumps({'type': 'message_stop'})}\n\n"


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """Proxy Chat requests to Moonshot (OpenAI Format)."""
    body = await request.json()
    if body.get("model") != MOONSHOT_MODEL:
        body["model"] = MOONSHOT_MODEL
    try:
        response = await client.post("/chat/completions", json=body)
        return JSONResponse(content=response.json(), status_code=response.status_code)
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)


@app.post("/v1/messages")
@app.post("/v1/v1/messages")
async def anthropic_messages(request: Request):
    """Bridge: Translate Anthropic requests to OpenAI format for Moonshot."""
    global kill_switch_active
    try:
        anthropic_body = await request.json()

        stream = anthropic_body.get("stream", False)

        raw_messages = anthropic_body.get("messages", [])
        openai_messages = convert_anthropic_messages(raw_messages)

        # ── Kill switch detection ─────────────────────────────────────────────
        # Check the last user message for KILL or GO.
        # KILL: strip all tools so Mimi cannot take any action.
        # GO:   restore tools and resume normal operation.
        last_user_text = ""
        for msg in reversed(raw_messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    last_user_text = content.strip()
                elif isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            last_user_text = block.get("text", "").strip()
                            break
                break

        if last_user_text.upper() == "KILL":
            kill_switch_active = True
            print("[KILL SWITCH] ACTIVATED — tools stripped from all requests")
        elif last_user_text.upper() == "GO":
            kill_switch_active = False
            print("[KILL SWITCH] DEACTIVATED — resuming normal operation")

        # Add system prompt
        system = anthropic_body.get("system")
        if system:
            if isinstance(system, list):
                system_text = " ".join(block.get("text", "") for block in system if isinstance(block, dict))
            else:
                system_text = str(system)
            openai_messages.insert(0, {"role": "system", "content": system_text})

        # ── Vision Loop-Back ──────────────────────────────────────────────────
        # Scan for image-producing tool calls and inject vision messages so
        # Mimi can see screenshots and photos without a human in the loop.
        openai_messages = scan_messages_for_vision_triggers(openai_messages)

        # Strip tools if kill switch is active — fires on every request,
        # including all branches of any spiral Mimi is running.
        if kill_switch_active:
            tools = None
            print("[KILL SWITCH] Tools stripped from this request")
        else:
            tools = convert_anthropic_tools(anthropic_body.get("tools"))

        openai_body = {
            "model": MOONSHOT_MODEL,
            "messages": openai_messages,
            "stream": False,
            "max_tokens": anthropic_body.get("max_tokens", 4096),
            "temperature": anthropic_body.get("temperature", 1.0),
        }
        if tools:
            openai_body["tools"] = tools

        print(f"[KIMI] Sending {len(openai_messages)} messages...")
        if tools:
            print(f"[KIMI] Tools: {[t['function']['name'] for t in tools]}")

        response = await client.post("/chat/completions", json=openai_body)

        if response.status_code != 200:
            error_data = response.json()
            print(f"[ERROR] Kimi returned {response.status_code}: {error_data}")
            return JSONResponse(
                content={"error": {"type": "api_error", "message": str(error_data)}},
                status_code=response.status_code
            )

        openai_resp = response.json()

        finish_reason = openai_resp["choices"][0].get("finish_reason")
        print(f"[KIMI] Response OK. Finish reason: {finish_reason}")

        message = openai_resp["choices"][0]["message"]
        if message.get("reasoning_content"):
            print(f"[KIMI] reasoning_content present: {len(message['reasoning_content'])} chars")

        if message.get("tool_calls"):
            for tc in message["tool_calls"]:
                print(f"[KIMI] Tool call: {tc['function']['name']} (id={tc['id']})")

        if stream:
            return StreamingResponse(
                stream_anthropic_response(openai_resp, "claude-3-5-sonnet-20241022"),
                media_type="text/event-stream",
                headers={
                    "anthropic-version": "2023-06-01",
                    "x-proxy": "kimi-proxy-tool-enabled"
                }
            )
        else:
            content_blocks = []

            text_content = message.get("content", "")
            if text_content:
                content_blocks.append({"type": "text", "text": text_content})

            tool_calls = message.get("tool_calls", [])
            if tool_calls:
                for tc in tool_calls:
                    kimi_id = tc.get("id", "")
                    anthropic_id = generate_anthropic_id("toolu")
                    id_mapper.register(kimi_id, anthropic_id)

                    if message.get("reasoning_content"):
                        id_mapper.cache_reasoning(kimi_id, message["reasoning_content"])

                    tool_name = tc.get("function", {}).get("name", "unknown")
                    args_str = tc.get("function", {}).get("arguments", "{}")
                    try:
                        args = json.loads(args_str)
                    except Exception:
                        args = {}

                    content_blocks.append({
                        "type": "tool_use",
                        "id": anthropic_id,
                        "name": tool_name,
                        "input": args
                    })

            anthropic_resp = {
                "id": generate_anthropic_id("msg"),
                "type": "message",
                "role": "assistant",
                "content": content_blocks,
                "model": "claude-3-5-sonnet-20241022",
                "stop_reason": "tool_use" if tool_calls else "end_turn",
                "stop_sequence": None,
                "usage": {
                    "input_tokens": openai_resp.get("usage", {}).get("prompt_tokens", 0),
                    "output_tokens": openai_resp.get("usage", {}).get("completion_tokens", 0)
                }
            }

            return JSONResponse(content=anthropic_resp)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JSONResponse(
            content={"error": {"type": "server_error", "message": str(e)}},
            status_code=500
        )


@app.post("/v1/embeddings")
async def embeddings(request: Request):
    """Handle Embeddings LOCALLY (Bypass Moonshot)."""
    body = await request.json()
    input_text = body.get("input")
    if isinstance(input_text, str):
        input_text = [input_text]

    print(f"Generating local embeddings for {len(input_text)} inputs...")
    vectors = embedding_model.encode(input_text)

    data = []
    for i, vec in enumerate(vectors):
        data.append({
            "object": "embedding",
            "index": i,
            "embedding": vec.tolist()
        })

    return {
        "object": "list",
        "data": data,
        "model": "text-embedding-3-small-local",
        "usage": {"prompt_tokens": 0, "total_tokens": 0}
    }


@app.get("/v1/models")
async def list_models():
    return {
        "object": "list",
        "data": [
            {"id": MOONSHOT_MODEL, "object": "model", "owned_by": "moonshot"},
            {"id": "claude-3-5-sonnet-20241022", "object": "model", "owned_by": "anthropic"}
        ]
    }


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "mappings": len(id_mapper.kimi_to_anthropic),
        "reasoning_cache": len(id_mapper.reasoning_cache),
        "vision_triggers": list(VISION_TRIGGER_TOOLS.keys())
    }


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8080)
