"""
mcp_enforcement_server.py
--------------------------
MCP tool server that enforces Kiki's mandatory protocol gates.

Provides two tools:
  1. read_protocol  — forces Kiki to locate and re-read the relevant
                      protocol section already in her system prompt context.
                      No file reading. The text is already in her context.
  2. alert_human    — fires desktop notification and returns HALTED status.
                      Telegram is handled natively by MemU.

Install dependencies:
    /Library/Frameworks/Python.framework/Versions/3.11/bin/pip3 install mcp plyer

Register in MemU:
    Server Name:  Kiki-enforcement
    Command:      /Library/Frameworks/Python.framework/Versions/3.11/bin/python3
    Arguments:    /path/to/mcp_enforcement_server.py
"""

import asyncio
from datetime import datetime
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolResult,
)

try:
    from plyer import notification as plyer_notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False


# ── Config ────────────────────────────────────────────────────────────────────

WORKSPACE      = Path.home() / "Documents/memu-workspace"
AUDIT_LOG_PATH = WORKSPACE / "logs" / "protocol_audit.log"

PROTOCOL_KEYS = [
    "CAPTCHA_BLOCKER",
    "PLAYWRIGHT_VISIBILITY",
    "BUILD_COMPLETE",
    "PHYSICAL_INTERVENTION",
    "API_FAILURE",
    "VISION",
    "TRADING_VISION",
]

EMOJI_MAP = {
    "CAPTCHA_BLOCKER":       "🚨",
    "PLAYWRIGHT_VISIBILITY": "👁️",
    "BUILD_COMPLETE":        "🔍",
    "PHYSICAL_INTERVENTION": "🙋",
    "API_FAILURE":           "⚠️",
    "VISION":                "📷",
    "TRADING_VISION":        "📊",
}


# ── MCP Server ────────────────────────────────────────────────────────────────

server = Server("Kiki-enforcement")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="read_protocol",
            description=(
                "MANDATORY — Call this FIRST at any checkpoint before taking action. "
                "Forces Kiki to locate and re-read the exact protocol section in her "
                "system prompt context for the current situation. "
                "Valid keys: CAPTCHA_BLOCKER | PLAYWRIGHT_VISIBILITY | BUILD_COMPLETE | "
                "PHYSICAL_INTERVENTION | API_FAILURE | VISION | TRADING_VISION"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "protocol_key": {
                        "type": "string",
                        "enum": PROTOCOL_KEYS,
                        "description": (
                            "The protocol key matching the current checkpoint situation. "
                            "CAPTCHA_BLOCKER: any CAPTCHA or bot block encountered. "
                            "PLAYWRIGHT_VISIBILITY: headless browser needing human visibility. "
                            "BUILD_COMPLETE: about to declare any build or task done. "
                            "PHYSICAL_INTERVENTION: task requires Rudy to physically act. "
                            "API_FAILURE: critical API failed twice in a row. "
                            "VISION: about to describe or analyze any visual content. "
                            "TRADING_VISION: any market analysis or trade decision."
                        )
                    }
                },
                "required": ["protocol_key"]
            }
        ),
        Tool(
            name="alert_human",
            description=(
                "MANDATORY — Call after read_protocol() at every checkpoint. "
                "Sends a desktop notification to Rudy. Telegram is handled natively by MemU. "
                "Returns HALTED status — Kiki must not proceed until Rudy confirms. "
                "Never skip this at a mandatory gate."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "trigger": {
                        "type": "string",
                        "description": "Protocol key that caused this alert e.g. CAPTCHA_BLOCKER."
                    },
                    "situation": {
                        "type": "string",
                        "description": "Plain English: exactly what happened and why Kiki stopped."
                    },
                    "location": {
                        "type": "string",
                        "description": "URL, file path, or app name where the issue occurred."
                    },
                    "action_needed": {
                        "type": "string",
                        "description": "Precisely what Rudy needs to do to unblock the pipeline."
                    },
                    "next_step_after_confirmation": {
                        "type": "string",
                        "description": "What Kiki will do immediately after Rudy confirms."
                    },
                    "blocking": {
                        "type": "boolean",
                        "description": "If true, pipeline halts until Rudy confirms. Default: true.",
                        "default": True
                    }
                },
                "required": [
                    "trigger",
                    "situation",
                    "location",
                    "action_needed",
                    "next_step_after_confirmation"
                ]
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> CallToolResult:
    if name == "read_protocol":
        return await handle_read_protocol(arguments)
    elif name == "alert_human":
        return await handle_alert_human(arguments)
    else:
        return CallToolResult(
            content=[TextContent(type="text", text=f"Unknown tool: {name}")],
            isError=True
        )


# ── Tool 1: read_protocol ─────────────────────────────────────────────────────

async def handle_read_protocol(args: dict) -> CallToolResult:
    protocol_key = args.get("protocol_key", "").strip()

    if protocol_key not in PROTOCOL_KEYS:
        _log("UNKNOWN_PROTOCOL", protocol_key, "Invalid key attempted")
        return CallToolResult(
            content=[TextContent(
                type="text",
                text=(
                    f"ERROR: '{protocol_key}' is not a valid protocol key.\n"
                    f"Valid keys: {', '.join(PROTOCOL_KEYS)}\n\n"
                    f"You are at a checkpoint. Call alert_human() immediately."
                )
            )],
            isError=True
        )

    _log("PROTOCOL_READ", protocol_key, "Kiki directed to re-read system prompt section")

    response = (
        f"PROTOCOL GATE: {protocol_key}\n"
        f"{'=' * 60}\n\n"
        f"Locate the [PROTOCOL: {protocol_key}] section in your system prompt "
        f"right now and re-read it in full before taking any further action.\n\n"
        f"This section is already in your context. Find it. Read it. Follow it exactly.\n\n"
        f"{'=' * 60}\n"
        f"bypass_permitted:     FALSE\n"
        f"required_next_action: After re-reading, call alert_human() with full "
        f"context of the current situation before proceeding."
    )

    return CallToolResult(
        content=[TextContent(type="text", text=response)]
    )


# ── Tool 2: alert_human ───────────────────────────────────────────────────────

async def handle_alert_human(args: dict) -> CallToolResult:
    trigger   = args.get("trigger", "UNKNOWN")
    situation = args.get("situation", "")
    location  = args.get("location", "")
    action    = args.get("action_needed", "")
    next_step = args.get("next_step_after_confirmation", "")
    blocking  = args.get("blocking", True)

    emoji = EMOJI_MAP.get(trigger, "🔔")

    message = (
        f"{emoji} Kiki NEEDS YOU — {trigger}\n\n"
        f"Situation:     {situation}\n"
        f"Location:      {location}\n"
        f"What I need:   {action}\n"
        f"Once confirmed, I will: {next_step}\n\n"
        f"Reply CONFIRMED when done."
    )

    # Fire desktop notification
    desktop_ok = await asyncio.to_thread(_send_desktop, trigger, action, emoji)

    _log(
        "ALERT_SENT", trigger,
        f"Desktop:{'OK' if desktop_ok else 'FAIL'} | Telegram: MemU native"
    )

    if blocking:
        _log("PIPELINE_HALTED", trigger, "Awaiting human confirmation")

    channel_status = (
        f"  Desktop notification: {'✅ Sent' if desktop_ok else '❌ Failed — pip install plyer'}\n"
        f"  Telegram:             ✅ Handled natively by MemU\n"
        f"  MemU chat:            ✅ This message (always delivered)"
    )

    result_text = (
        f"ALERT DISPATCHED — {trigger}\n"
        f"{'─' * 60}\n"
        f"{message}\n"
        f"{'─' * 60}\n\n"
        f"Channels:\n{channel_status}\n\n"
        f"PIPELINE STATUS: "
        f"{'⛔ HALTED — do not proceed. Wait for Rudy to reply CONFIRMED.' if blocking else '✅ CONTINUING — informational alert only.'}"
    )

    return CallToolResult(
        content=[TextContent(type="text", text=result_text)]
    )


# ── Desktop notification ──────────────────────────────────────────────────────

def _send_desktop(trigger: str, action: str, emoji: str) -> bool:
    if not PLYER_AVAILABLE:
        return False
    try:
        plyer_notification.notify(
            title=f"{emoji} Kiki: {trigger}",
            message=action[:256],
            app_name="Kiki Enforcement",
            timeout=30
        )
        return True
    except Exception:
        return False


# ── Audit log ─────────────────────────────────────────────────────────────────

def _log(event_type: str, protocol_key: str, note: str):
    try:
        AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"{timestamp} | {event_type:<22} | {protocol_key:<25} | {note}\n"
        with open(AUDIT_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception:
        pass


# ── Entry point ───────────────────────────────────────────────────────────────

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
